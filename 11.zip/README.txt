﻿このアプリケーションは Apache License, Version 2.0 のライセンスで配布されている成果物を含んでいます。
http://www.apache.org/licenses/LICENSE-2.0
